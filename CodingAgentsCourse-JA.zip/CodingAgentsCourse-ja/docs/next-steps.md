# 次のステップ

!!! tip "ワークショップはこれで終わりです"

    `uip` CLI のセットアップから始まり、エージェントの構築、そして Maestro でのオーケストレーションまでを、コーディングエージェントと一緒に進めてきました。

## 引き続き構築する

- 自分のユースケースとデータで、各演習をもう一度やってみましょう。
- 同じ UiPath スキルを使って、別のコーディングエージェント（Cursor、Gemini CLI、Codex）を試してみましょう。
- Maestro ソリューションに、エージェントや人的判断のステップを追加して拡張してみましょう。

## もっと詳しく

| リソース | 説明 |
|----------|------|
| [UiPath CLI ドキュメント](https://docs.uipath.com/uipath-cli) | `uip` CLI の公式リファレンスとハウツーガイド |
| [UiPath skills（GitHub）](https://github.com/uipath/skills) | コーディングエージェント向け UiPath スキルのソース |
| [Coding Agents（UiPath）](https://www.uipath.com/developers/coding-agents) | 製品概要 |
